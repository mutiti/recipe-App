export class Thing {
  _id: string;
  title: string;
  description: string;
  imageUrl: string;
  price: number;
  userId: string;
}
